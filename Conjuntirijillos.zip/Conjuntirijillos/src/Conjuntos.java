
public class Conjuntos {
	public static void main(String []args){
		new Ventana();
	}
}
